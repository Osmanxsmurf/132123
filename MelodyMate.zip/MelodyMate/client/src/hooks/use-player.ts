import { useState, useRef, useCallback, useEffect } from "react";
import { Track } from "@shared/schema";

interface UsePlayerReturn {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isShuffling: boolean;
  isRepeating: boolean;
  queue: Track[];
  currentIndex: number;
  play: (track?: Track) => void;
  pause: () => void;
  toggle: () => void;
  seekTo: (time: number) => void;
  setVolume: (volume: number) => void;
  previousTrack: () => void;
  nextTrack: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  addToQueue: (track: Track) => void;
  setQueue: (tracks: Track[], startIndex?: number) => void;
  toggleLike: () => void;
}

export function usePlayer(): UsePlayerReturn {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.7);
  const [isShuffling, setIsShuffling] = useState(false);
  const [isRepeating, setIsRepeating] = useState(false);
  const [queue, setQueueState] = useState<Track[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize audio element
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.addEventListener("loadedmetadata", () => {
        setDuration(audioRef.current?.duration || 0);
      });
      audioRef.current.addEventListener("ended", () => {
        if (isRepeating) {
          audioRef.current?.play();
        } else {
          nextTrack();
        }
      });
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRepeating]);

  // Update time progress
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        if (audioRef.current) {
          setCurrentTime(audioRef.current.currentTime);
        }
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPlaying]);

  const play = useCallback((track?: Track) => {
    if (track && track !== currentTrack) {
      setCurrentTrack(track);
      if (audioRef.current) {
        // For demo purposes, we'll use a placeholder audio file
        // In a real app, this would be the track's preview URL or stream URL
        audioRef.current.src = track.previewUrl || "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmEaAzWPz+/RdCkGKILM8dqOOgcYc7gA7qZODwxLqOHyoFkQC0ql4vK6Y";
        audioRef.current.volume = volume;
        audioRef.current.load();
      }
    }

    if (audioRef.current) {
      audioRef.current.play();
      setIsPlaying(true);
    }
  }, [currentTrack, volume]);

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  }, []);

  const toggle = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }, [isPlaying, play, pause]);

  const seekTo = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  }, []);

  const setVolume = useCallback((newVolume: number) => {
    setVolumeState(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  }, []);

  const previousTrack = useCallback(() => {
    if (queue.length === 0) return;

    let newIndex;
    if (isShuffling) {
      newIndex = Math.floor(Math.random() * queue.length);
    } else {
      newIndex = currentIndex > 0 ? currentIndex - 1 : queue.length - 1;
    }

    setCurrentIndex(newIndex);
    play(queue[newIndex]);
  }, [queue, currentIndex, isShuffling, play]);

  const nextTrack = useCallback(() => {
    if (queue.length === 0) return;

    let newIndex;
    if (isShuffling) {
      newIndex = Math.floor(Math.random() * queue.length);
    } else {
      newIndex = currentIndex < queue.length - 1 ? currentIndex + 1 : 0;
    }

    setCurrentIndex(newIndex);
    play(queue[newIndex]);
  }, [queue, currentIndex, isShuffling, play]);

  const toggleShuffle = useCallback(() => {
    setIsShuffling(!isShuffling);
  }, [isShuffling]);

  const toggleRepeat = useCallback(() => {
    setIsRepeating(!isRepeating);
  }, [isRepeating]);

  const addToQueue = useCallback((track: Track) => {
    setQueueState(prev => [...prev, track]);
  }, []);

  const setQueue = useCallback((tracks: Track[], startIndex = 0) => {
    setQueueState(tracks);
    setCurrentIndex(startIndex);
    if (tracks.length > 0) {
      play(tracks[startIndex]);
    }
  }, [play]);

  const toggleLike = useCallback(() => {
    if (currentTrack) {
      // This would typically update the track's like status via API
      setCurrentTrack(prev => 
        prev ? { ...prev, isLiked: !prev.isLiked } : null
      );
    }
  }, [currentTrack]);

  return {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isShuffling,
    isRepeating,
    queue,
    currentIndex,
    play,
    pause,
    toggle,
    seekTo,
    setVolume,
    previousTrack,
    nextTrack,
    toggleShuffle,
    toggleRepeat,
    addToQueue,
    setQueue,
    toggleLike,
  };
}
