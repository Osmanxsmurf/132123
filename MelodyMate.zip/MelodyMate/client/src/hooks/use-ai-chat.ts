import { useState, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { AiInteraction } from "@shared/schema";

interface ChatMessage {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
  recommendations?: string[];
}

interface UseAiChatReturn {
  messages: ChatMessage[];
  isLoading: boolean;
  sendMessage: (message: string) => Promise<void>;
  clearChat: () => void;
}

export function useAiChat(): UseAiChatReturn {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      type: "ai",
      content: "Merhaba! Ben Marjinal, Müzik Asistanınızın yapay zeka destekli müzik asistanıyım. Size nasıl yardımcı olabilirim? Ruh halinize, zevkinize ve anlık ihtiyaçlarınıza göre özel müzik önerileri sunabilirim. Hangi türde müzik arıyorsunuz?",
      timestamp: new Date(),
    },
  ]);

  const queryClient = useQueryClient();

  const { data: interactions } = useQuery({
    queryKey: ["/api/ai/interactions"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const chatMutation = useMutation({
    mutationFn: (query: string) => api.ai.chat(query),
    onSuccess: (interaction: AiInteraction, query: string) => {
      // Add user message
      const userMessage: ChatMessage = {
        id: `user_${Date.now()}`,
        type: "user",
        content: query,
        timestamp: new Date(),
      };

      // Add AI response
      const aiMessage: ChatMessage = {
        id: interaction.id,
        type: "ai",
        content: interaction.response,
        timestamp: interaction.createdAt || new Date(),
        recommendations: interaction.recommendations ? interaction.recommendations : undefined,
      };

      setMessages(prev => [...prev, userMessage, aiMessage]);
      
      // Invalidate AI interactions cache
      queryClient.invalidateQueries({ queryKey: ["/api/ai/interactions"] });
    },
    onError: (error) => {
      const errorMessage: ChatMessage = {
        id: `error_${Date.now()}`,
        type: "ai",
        content: "Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    },
  });

  const sendMessage = useCallback(async (message: string) => {
    if (!message.trim()) return;
    
    await chatMutation.mutateAsync(message.trim());
  }, [chatMutation]);

  const clearChat = useCallback(() => {
    setMessages([
      {
        id: "welcome",
        type: "ai",
        content: "Merhaba! Ben Marjinal, Müzik Asistanınızın yapay zeka destekli müzik asistanıyım. Size nasıl yardımcı olabilirim? Ruh halinize, zevkinize ve anlık ihtiyaçlarınıza göre özel müzik önerileri sunabilirim. Hangi türde müzik arıyorsunuz?",
        timestamp: new Date(),
      },
    ]);
  }, []);

  return {
    messages,
    isLoading: chatMutation.isPending,
    sendMessage,
    clearChat,
  };
}
