import { Button } from "@/components/ui/button";
import { SIDEBAR_NAVIGATION, LIBRARY_NAVIGATION } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { api } from "@/lib/api";
import type { Playlist } from "@shared/schema";

interface SidebarProps {
  onOpenAiChat: () => void;
}

export function Sidebar({ onOpenAiChat }: SidebarProps) {
  const [, setLocation] = useLocation();
  
  const { data: playlists = [] } = useQuery({
    queryKey: ["/api/playlists"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const playlistsTyped = playlists as Playlist[];
  const aiPlaylists = playlistsTyped.filter(p => p.isAiGenerated);

  return (
    <div className="w-64 bg-gray-900 flex flex-col border-r border-gray-800">
      {/* Logo */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
            <i className="fas fa-brain text-white text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Müzik Asistanım</h1>
            <p className="text-xs text-gray-400">Marjinal AI ile Keşfet</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          {SIDEBAR_NAVIGATION.map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => setLocation(item.path)}
              className={`w-full justify-start px-3 py-2 rounded-lg transition-colors ${
                item.active
                  ? "bg-purple-600/20 text-purple-400 border border-purple-500/30"
                  : "text-gray-400 hover:text-white hover:bg-gray-800"
              }`}
            >
              <i className={`${item.icon} w-5 mr-3`} />
              <span className="font-medium">{item.title}</span>
            </Button>
          ))}
        </div>

        <div className="pt-4 border-t border-gray-800">
          <h3 className="text-xs uppercase text-gray-400 font-semibold mb-3 px-3">
            Kütüphanem
          </h3>
          <div className="space-y-1">
            {LIBRARY_NAVIGATION.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                className="w-full justify-start px-3 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
              >
                <i className={`${item.icon} w-5 mr-3`} />
                <span>{item.title}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* AI Playlists */}
        {aiPlaylists.length > 0 && (
          <div className="pt-4 border-t border-gray-800">
            <h3 className="text-xs uppercase text-gray-400 font-semibold mb-3 px-3">
              AI Önerileri
            </h3>
            <div className="space-y-1">
              {aiPlaylists.slice(0, 3).map((playlist) => (
                <Button
                  key={playlist.id}
                  variant="ghost"
                  className="w-full justify-start px-3 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
                >
                  <div className="flex items-center space-x-3 w-full">
                    <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded flex-shrink-0" />
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-sm font-medium text-white truncate">
                        {playlist.name}
                      </p>
                      <p className="text-xs text-gray-400">
                        {playlist.trackIds?.length || 0} şarkı • AI
                      </p>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* AI Chat Toggle */}
      <div className="p-4 border-t border-gray-800">
        <Button
          onClick={onOpenAiChat}
          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 rounded-xl font-semibold transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/25"
        >
          <i className="fas fa-robot mr-2" />
          AI Asistanı
        </Button>
      </div>
    </div>
  );
}
