import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrackCard } from "@/components/track-card";
import { api } from "@/lib/api";
import { QUICK_ACTIONS } from "@/lib/constants";
import { usePlayer } from "@/hooks/use-player";

export default function Home() {
  const { setQueue } = usePlayer();

  const { data: trendingTracks = [], isLoading: trendingLoading } = useQuery({
    queryKey: ["/api/tracks/trending"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: playlists = [] } = useQuery({
    queryKey: ["/api/playlists"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const aiPlaylists = playlists.filter(p => p.isAiGenerated);

  const handlePlayAllTrending = () => {
    if (trendingTracks.length > 0) {
      setQueue(trendingTracks);
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-gradient-to-b from-gray-900 to-black">
      <div className="p-6 space-y-8 pb-32">
        {/* Hero Section */}
        <section className="relative">
          <div 
            className="relative h-64 rounded-2xl overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(139, 92, 246, 0.3) 0%, rgba(59, 130, 246, 0.3) 50%, rgba(29, 185, 84, 0.3) 100%), url('https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=600') center/cover"
            }}
          >
            <div className="absolute inset-0 bg-black/60" />
            <div className="relative h-full flex items-center p-8">
              <div className="max-w-2xl">
                <h2 className="text-4xl font-bold mb-4 text-white">
                  Yapay Zeka ile Müziği Yeniden Keşfet
                </h2>
                <p className="text-xl text-gray-300 mb-6">
                  MelodyAI, zevklerinizi öğrenir ve size özel müzik önerileri sunar. 
                  Ruh halinize göre playlist'ler oluşturur.
                </p>
                <Button 
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 rounded-xl font-semibold transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/25"
                >
                  <i className="fas fa-magic mr-2" />
                  AI'ya Sor
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {QUICK_ACTIONS.map((action) => (
              <Card 
                key={action.id}
                className="bg-gray-800 border-gray-700 hover:bg-gray-700 transition-all duration-300 cursor-pointer group"
              >
                <CardContent className="p-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${action.gradient} rounded-lg flex items-center justify-center mb-3`}>
                    <i className={`${action.icon} text-white`} />
                  </div>
                  <h3 className="font-semibold mb-1 text-white group-hover:text-gray-200">
                    {action.title}
                  </h3>
                  <p className="text-sm text-gray-400">{action.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Trending Music */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-white">Şu An Trend</h3>
            <div className="flex items-center space-x-3">
              {trendingTracks.length > 0 && (
                <Button
                  onClick={handlePlayAllTrending}
                  size="sm"
                  className="bg-green-500 hover:bg-green-400 text-black rounded-full"
                >
                  <i className="fas fa-play mr-2" />
                  Tümünü Çal
                </Button>
              )}
              <Button 
                variant="ghost" 
                className="text-gray-400 hover:text-white text-sm font-medium"
              >
                Tümünü Gör
              </Button>
            </div>
          </div>

          {trendingLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-gray-800 p-4 rounded-xl animate-pulse">
                  <div className="w-full aspect-square bg-gray-700 rounded-lg mb-4" />
                  <div className="h-4 bg-gray-700 rounded mb-2" />
                  <div className="h-3 bg-gray-700 rounded w-3/4" />
                </div>
              ))}
            </div>
          ) : trendingTracks.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {trendingTracks.slice(0, 8).map((track) => (
                <TrackCard key={track.id} track={track} />
              ))}
            </div>
          ) : (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-music text-2xl text-gray-400" />
                </div>
                <h4 className="text-lg font-semibold text-white mb-2">Henüz Trend Müzik Yok</h4>
                <p className="text-gray-400 mb-4">
                  Müzik keşfetmeye başlayın ve trendleri görün.
                </p>
                <Button 
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Müzik Keşfet
                </Button>
              </CardContent>
            </Card>
          )}
        </section>

        {/* AI Recommendations */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <i className="fas fa-brain text-white text-sm" />
              </div>
              <h3 className="text-2xl font-bold text-white">Sizin İçin AI Önerileri</h3>
            </div>
            <Button 
              variant="ghost"
              className="text-gray-400 hover:text-white text-sm font-medium"
            >
              Yenile
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <i className="fas fa-heart text-red-400" />
                  <h4 className="font-semibold text-white">Ruh Halinize Göre</h4>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  Son dinlediğiniz şarkılara göre, sakin ve melankolik parçalar seçtik.
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Sakin", "Melankolik", "Türkçe Pop"].map((tag) => (
                    <Button
                      key={tag}
                      variant="ghost"
                      size="sm"
                      className="bg-white/10 hover:bg-white/20 text-xs text-white px-3 py-1 rounded-full"
                    >
                      {tag}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-900/50 to-teal-900/50 border-green-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <i className="fas fa-compass text-green-400" />
                  <h4 className="font-semibold text-white">Yeni Keşifler</h4>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  Zevkinize uygun ama daha önce dinlemediğiniz sanatçılar.
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Alternatif", "Indie", "Elektronik"].map((tag) => (
                    <Button
                      key={tag}
                      variant="ghost"
                      size="sm"
                      className="bg-white/10 hover:bg-white/20 text-xs text-white px-3 py-1 rounded-full"
                    >
                      {tag}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* AI Generated Playlists */}
        {aiPlaylists.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">AI Önerilen Listeler</h3>
              <Button 
                variant="ghost"
                className="text-gray-400 hover:text-white text-sm font-medium"
              >
                Tümünü Gör
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {aiPlaylists.slice(0, 4).map((playlist) => (
                <Card key={playlist.id} className="bg-gray-800 border-gray-700 hover:bg-gray-700 transition-colors cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <i className="fas fa-brain text-white text-xl" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-lg mb-2 text-white">
                          {playlist.name}
                        </h4>
                        <p className="text-gray-400 text-sm mb-3">
                          {playlist.description || "AI tarafından oluşturuldu"}
                        </p>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs bg-blue-600/20 text-blue-400 px-2 py-1 rounded-full">
                            AI Önerisi
                          </span>
                          <span className="text-xs text-gray-500">
                            {playlist.trackIds?.length || 0} şarkı
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="w-10 h-10 bg-green-500 hover:bg-green-400 text-black rounded-full"
                      >
                        <i className="fas fa-play text-sm" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
