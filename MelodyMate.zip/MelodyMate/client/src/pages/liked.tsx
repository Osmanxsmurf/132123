import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrackCard } from "@/components/track-card";
import { Input } from "@/components/ui/input";
import { usePlayer } from "@/hooks/use-player";
import { api } from "@/lib/api";

export default function Liked() {
  const [searchQuery, setSearchQuery] = useState("");
  const { setQueue } = usePlayer();
  const queryClient = useQueryClient();

  const { data: allTracks = [] } = useQuery({
    queryKey: ["/api/tracks"],
    staleTime: 5 * 60 * 1000,
  });

  const { data: userPreferences } = useQuery({
    queryKey: ["/api/user/preferences"],
    staleTime: 5 * 60 * 1000,
  });

  const tracksData = allTracks as any[];
  const likedTracks = tracksData.filter(track => track.isLiked);
  
  const filteredTracks = likedTracks.filter(track => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return track.title.toLowerCase().includes(query) ||
           track.artist.toLowerCase().includes(query) ||
           track.album?.toLowerCase().includes(query);
  });

  const createPlaylistMutation = useMutation({
    mutationFn: (playlistData: any) => api.playlists.create(playlistData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/playlists"] });
    },
  });

  const playAllLiked = () => {
    if (filteredTracks.length > 0) {
      setQueue(filteredTracks);
    }
  };

  const createPlaylistFromLiked = async () => {
    await createPlaylistMutation.mutateAsync({
      name: "Beğendiklerim - " + new Date().toLocaleDateString('tr-TR'),
      description: "Beğendiğim şarkılardan oluşturulan playlist",
      trackIds: likedTracks.map(track => track.id),
      isAiGenerated: false,
    });
  };

  const groupedByArtist = likedTracks.reduce((acc, track) => {
    const artist = track.artist;
    if (!acc[artist]) acc[artist] = [];
    acc[artist].push(track);
    return acc;
  }, {} as Record<string, any[]>);

  const topArtists = Object.entries(groupedByArtist)
    .sort(([, a], [, b]) => b.length - a.length)
    .slice(0, 5);

  return (
    <main className="flex-1 overflow-y-auto bg-gradient-to-b from-gray-900 to-black">
      <div className="p-6 space-y-8 pb-32">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Beğendiklerim</h1>
              <p className="text-gray-400">
                {likedTracks.length} beğenilen şarkı
              </p>
            </div>
            
            <div className="flex space-x-3">
              {likedTracks.length > 0 && (
                <>
                  <Button
                    onClick={createPlaylistFromLiked}
                    disabled={createPlaylistMutation.isPending}
                    variant="outline"
                    className="border-purple-600 text-purple-400 hover:bg-purple-600/20"
                  >
                    <i className="fas fa-plus mr-2" />
                    Playlist Oluştur
                  </Button>
                  <Button
                    onClick={playAllLiked}
                    className="bg-green-500 hover:bg-green-400 text-black rounded-full px-6"
                  >
                    <i className="fas fa-play mr-2" />
                    Tümünü Çal
                  </Button>
                </>
              )}
            </div>
          </div>

          {likedTracks.length > 0 && (
            <div className="relative max-w-md">
              <Input
                type="text"
                placeholder="Beğendiğin şarkılarda ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-800 border-gray-700 pl-10 pr-4 py-2 rounded-lg focus:ring-2 focus:ring-purple-500/50"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          )}
        </div>

        {/* Content */}
        {likedTracks.length === 0 ? (
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-12 text-center">
              <div className="w-24 h-24 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-heart text-4xl text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">
                Henüz beğendiğin şarkı yok
              </h3>
              <p className="text-gray-400 mb-6 max-w-md mx-auto">
                Sevdiğin şarkıları beğen ve buradan kolayca erişebilirsin. 
                Beğendiğin şarkıları AI asistanımız da öğrenir ve daha iyi öneriler sunar.
              </p>
              <Button 
                onClick={() => window.location.href = '/search'}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 rounded-xl"
              >
                <i className="fas fa-search mr-2" />
                Müzik Keşfet
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {/* Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-r from-red-900/50 to-pink-900/50 border-red-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
                      <i className="fas fa-heart text-white text-xl" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-white">{likedTracks.length}</p>
                      <p className="text-gray-400">Beğenilen Şarkı</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                      <i className="fas fa-user-music text-white text-xl" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-white">{Object.keys(groupedByArtist).length}</p>
                      <p className="text-gray-400">Farklı Sanatçı</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-r from-green-900/50 to-teal-900/50 border-green-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                      <i className="fas fa-clock text-white text-xl" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-white">
                        {Math.floor(likedTracks.reduce((sum, track) => sum + (track.duration || 180), 0) / 60)}
                      </p>
                      <p className="text-gray-400">Dakika Müzik</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Artists */}
            {topArtists.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-white">En Çok Beğendiğin Sanatçılar</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {topArtists.map(([artist, tracks]) => (
                    <Card key={artist} className="bg-gray-800 border-gray-700 hover:bg-gray-700 transition-colors cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                            <i className="fas fa-user-music text-white text-xl" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white truncate">{artist}</h3>
                            <p className="text-sm text-gray-400">
                              {tracks.length} beğenilen şarkı
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Liked Tracks */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-white">
                  {searchQuery ? `Arama Sonuçları (${filteredTracks.length})` : "Tüm Beğendiğin Şarkılar"}
                </h2>
                {searchQuery && (
                  <Button
                    onClick={() => setSearchQuery("")}
                    variant="ghost"
                    className="text-gray-400 hover:text-white"
                  >
                    Aramayı Temizle
                  </Button>
                )}
              </div>

              {filteredTracks.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {filteredTracks.map((track: any) => (
                    <TrackCard key={track.id} track={track} />
                  ))}
                </div>
              ) : (
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-8 text-center">
                    <i className="fas fa-search text-4xl text-gray-400 mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">
                      Arama sonucu bulunamadı
                    </h3>
                    <p className="text-gray-400">
                      "{searchQuery}" için beğendiğin şarkılarda sonuç bulunamadı.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}