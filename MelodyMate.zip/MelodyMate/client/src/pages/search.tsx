import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { TrackCard } from "@/components/track-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { usePlayer } from "@/hooks/use-player";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  const { setQueue } = usePlayer();

  // Load search results from session storage if available
  useEffect(() => {
    const savedResults = sessionStorage.getItem('searchResults');
    const savedQuery = sessionStorage.getItem('searchQuery');
    if (savedResults && savedQuery) {
      setSearchResults(JSON.parse(savedResults));
      setSearchQuery(savedQuery);
    }
  }, []);

  const { data: trendingTracks = [] } = useQuery({
    queryKey: ["/api/tracks/trending"],
    staleTime: 10 * 60 * 1000,
  });

  const handleSearch = async (query: string) => {
    if (!query.trim()) return;
    
    setIsSearching(true);
    try {
      // Search local tracks
      const localTracks = await api.tracks.search(query);
      
      // Search external platforms
      const externalTracks = await api.external.search(query);
      
      const allResults = [...localTracks, ...externalTracks];
      setSearchResults(allResults);
      
      // Save to session storage
      sessionStorage.setItem('searchResults', JSON.stringify(allResults));
      sessionStorage.setItem('searchQuery', query);
      
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(searchQuery);
  };

  const filteredResults = searchResults.filter(track => {
    if (activeTab === "all") return true;
    return track.platform === activeTab;
  });

  const platforms = Array.from(new Set(searchResults.map(track => track.platform)));

  const playAllResults = () => {
    if (filteredResults.length > 0) {
      setQueue(filteredResults);
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-gradient-to-b from-gray-900 to-black">
      <div className="p-6 space-y-8 pb-32">
        {/* Search Header */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Müzik Ara</h1>
            <p className="text-gray-400">Milyonlarca şarkı, sanatçı ve albüm arasından arama yapın</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative max-w-2xl">
              <Input
                type="text"
                placeholder="Şarkı, sanatçı, albüm ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-800 border-gray-700 pl-12 pr-4 py-4 text-lg rounded-xl focus:ring-2 focus:ring-purple-500/50 focus:bg-gray-700 transition-all"
              />
              <i className="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg" />
              <Button
                type="submit"
                disabled={!searchQuery.trim() || isSearching}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-2 rounded-lg"
              >
                {isSearching ? (
                  <i className="fas fa-spinner fa-spin" />
                ) : (
                  "Ara"
                )}
              </Button>
            </div>
          </form>
        </div>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">Arama Sonuçları</h2>
                <p className="text-gray-400">"{searchQuery}" için {searchResults.length} sonuç bulundu</p>
              </div>
              {filteredResults.length > 0 && (
                <Button
                  onClick={playAllResults}
                  className="bg-green-500 hover:bg-green-400 text-black rounded-full px-6"
                >
                  <i className="fas fa-play mr-2" />
                  Tümünü Çal
                </Button>
              )}
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="bg-gray-800 border-gray-700">
                <TabsTrigger value="all" className="data-[state=active]:bg-purple-600">
                  Tümü ({searchResults.length})
                </TabsTrigger>
                {platforms.map(platform => (
                  <TabsTrigger 
                    key={platform} 
                    value={platform}
                    className="data-[state=active]:bg-purple-600 capitalize"
                  >
                    {platform} ({searchResults.filter(t => t.platform === platform).length})
                  </TabsTrigger>
                ))}
              </TabsList>

              <TabsContent value={activeTab} className="mt-6">
                {filteredResults.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                    {filteredResults.map((track, index) => (
                      <div key={`${track.platform}-${track.id || index}`} className="relative">
                        <TrackCard track={track} />
                        <Badge 
                          variant="secondary" 
                          className="absolute top-2 right-2 bg-gray-900/80 text-xs"
                        >
                          {track.platform}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-8 text-center">
                      <i className="fas fa-search text-4xl text-gray-400 mb-4" />
                      <h3 className="text-lg font-semibold text-white mb-2">
                        Bu kategoride sonuç bulunamadı
                      </h3>
                      <p className="text-gray-400">
                        Farklı bir kategori deneyin veya arama terimini değiştirin.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Trending when no search */}
        {searchResults.length === 0 && !isSearching && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Şu An Trend</h2>
              <p className="text-gray-400">En çok dinlenen şarkılar</p>
            </div>

            {(trendingTracks as any[]).length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {(trendingTracks as any[]).map((track: any) => (
                  <TrackCard key={track.id} track={track} />
                ))}
              </div>
            ) : (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-8 text-center">
                  <i className="fas fa-fire text-4xl text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Trend müzikler yükleniyor
                  </h3>
                  <p className="text-gray-400">
                    En popüler şarkılar yakında görünecek.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Empty state for failed search */}
        {searchResults.length === 0 && !isSearching && searchQuery && (
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-8 text-center">
              <i className="fas fa-music text-4xl text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">
                Sonuç bulunamadı
              </h3>
              <p className="text-gray-400 mb-4">
                "{searchQuery}" için sonuç bulunamadı. Farklı anahtar kelimeler deneyin.
              </p>
              <Button 
                onClick={() => setSearchQuery("")}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Aramayı Temizle
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Quick Search Suggestions */}
        {!searchQuery && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Popüler Aramalar</h3>
            <div className="flex flex-wrap gap-2">
              {["Sezen Aksu", "Tarkan", "Türkçe Pop", "Müslüm Gürses", "Ceza", "Melankolik", "Enerjik"].map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSearchQuery(suggestion);
                    handleSearch(suggestion);
                  }}
                  className="bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white px-4 py-2 rounded-full transition-colors border border-gray-700"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}