import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrackCard } from "@/components/track-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePlayer } from "@/hooks/use-player";
import { MUSIC_GENRES } from "@/lib/constants";

export default function Trending() {
  const { setQueue } = usePlayer();
  
  const { data: trendingTracks = [], isLoading } = useQuery({
    queryKey: ["/api/tracks/trending"],
    staleTime: 10 * 60 * 1000,
  });

  const { data: allTracks = [] } = useQuery({
    queryKey: ["/api/tracks"],
    staleTime: 5 * 60 * 1000,
  });

  const tracksData = allTracks as any[];
  const trendingData = trendingTracks as any[];

  const getTracksByGenre = (genre: string) => {
    if (genre === "Tümü") return tracksData;
    
    return tracksData.filter(track => {
      const artistLower = track.artist.toLowerCase();
      const titleLower = track.title.toLowerCase();
      
      switch (genre) {
        case "Türkçe Pop":
          return artistLower.includes("sezen") || artistLower.includes("tarkan") || 
                 artistLower.includes("ajda") || artistLower.includes("sertab");
        case "Arabesk":
          return artistLower.includes("müslüm") || artistLower.includes("orhan");
        case "Hip Hop":
          return artistLower.includes("ceza") || titleLower.includes("rap");
        case "Rock":
          return artistLower.includes("haluk");
        default:
          return track.playCount > 500000;
      }
    });
  };

  const playAllTrending = () => {
    if (trendingData.length > 0) {
      setQueue(trendingData);
    }
  };

  return (
    <main className="flex-1 overflow-y-auto bg-gradient-to-b from-gray-900 to-black">
      <div className="p-6 space-y-8 pb-32">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Trend Müzikler</h1>
              <p className="text-gray-400">En popüler ve trending şarkılar</p>
            </div>
            
            {trendingData.length > 0 && (
              <Button
                onClick={playAllTrending}
                className="bg-green-500 hover:bg-green-400 text-black rounded-full px-6"
              >
                <i className="fas fa-play mr-2" />
                Trending Çal
              </Button>
            )}
          </div>
        </div>

        {/* Top Trending Section */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Şu An En Trend</h2>
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="bg-gray-800 p-4 rounded-xl animate-pulse">
                    <div className="w-full aspect-square bg-gray-700 rounded-lg mb-4" />
                    <div className="h-4 bg-gray-700 rounded mb-2" />
                    <div className="h-3 bg-gray-700 rounded w-3/4" />
                  </div>
                ))}
              </div>
            ) : trendingData.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {trendingData.slice(0, 8).map((track: any, index: number) => (
                  <div key={track.id} className="relative">
                    <TrackCard track={track} />
                    <div className="absolute top-2 left-2 bg-gradient-to-r from-red-500 to-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                      #{index + 1}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-8 text-center">
                  <i className="fas fa-fire text-4xl text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">Trend müzikler yükleniyor</h3>
                  <p className="text-gray-400">En popüler şarkılar yakında görünecek.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </section>

        {/* Genre-based Trending */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-4">Türlere Göre Popüler</h2>
            
            <Tabs defaultValue="Tümü" className="space-y-6">
              <TabsList className="bg-gray-800 border-gray-700 flex-wrap h-auto p-1">
                {["Tümü", "Türkçe Pop", "Arabesk", "Hip Hop", "Rock"].map((genre) => (
                  <TabsTrigger 
                    key={genre} 
                    value={genre}
                    className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-gray-300 px-4 py-2 rounded-md"
                  >
                    {genre}
                  </TabsTrigger>
                ))}
              </TabsList>

              {["Tümü", "Türkçe Pop", "Arabesk", "Hip Hop", "Rock"].map((genre) => {
                const genreTracks = getTracksByGenre(genre);
                const sortedTracks = genreTracks.sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
                
                return (
                  <TabsContent key={genre} value={genre}>
                    {sortedTracks.length > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {sortedTracks.slice(0, 12).map((track: any) => (
                          <TrackCard key={track.id} track={track} />
                        ))}
                      </div>
                    ) : (
                      <Card className="bg-gray-800 border-gray-700">
                        <CardContent className="p-8 text-center">
                          <i className="fas fa-music text-4xl text-gray-400 mb-4" />
                          <h3 className="text-lg font-semibold text-white mb-2">
                            {genre} kategorisinde müzik bulunamadı
                          </h3>
                          <p className="text-gray-400">
                            Bu kategori için yakında içerik eklenecek.
                          </p>
                        </CardContent>
                      </Card>
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </div>
        </section>

        {/* Platform Statistics */}
        <section className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Platform İstatistikleri</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                    <i className="fas fa-music text-white text-xl" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{tracksData.length}</p>
                    <p className="text-gray-400">Toplam Şarkı</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-900/50 to-teal-900/50 border-green-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                    <i className="fas fa-play text-white text-xl" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">
                      {Math.floor(tracksData.reduce((sum, track) => sum + (track.playCount || 0), 0) / 1000)}K
                    </p>
                    <p className="text-gray-400">Toplam Dinlenme</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-red-900/50 to-pink-900/50 border-red-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
                    <i className="fas fa-heart text-white text-xl" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">
                      {tracksData.filter(track => track.isLiked).length}
                    </p>
                    <p className="text-gray-400">Beğenilen Şarkı</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </main>
  );
}