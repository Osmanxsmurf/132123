export const MUSIC_GENRES = [
  "Pop",
  "Rock",
  "Hip Hop",
  "Elektronik",
  "Jazz",
  "Klasik",
  "R&B",
  "Country",
  "Blues",
  "Reggae",
  "Punk",
  "Metal",
  "Türkçe Pop",
  "Arabesk",
  "Folk",
  "Alternative",
  "Indie",
] as const;

export const QUICK_ACTIONS = [
  {
    id: "trending",
    title: "Trendler",
    description: "En popüler müzikler",
    icon: "fas fa-fire",
    gradient: "from-red-500 to-orange-500",
  },
  {
    id: "discover",
    title: "Keşfet",
    description: "Yeni müzikler bul",
    icon: "fas fa-chart-line",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    id: "favorites",
    title: "Favoriler",
    description: "Beğendiğin şarkılar",
    icon: "fas fa-heart",
    gradient: "from-pink-500 to-red-500",
  },
  {
    id: "history",
    title: "Geçmiş",
    description: "Son dinlenenler",
    icon: "fas fa-history",
    gradient: "from-purple-500 to-indigo-500",
  },
] as const;

export const AI_QUICK_PROMPTS = [
  "Ruh halime göre müzik",
  "Yeni keşifler",
  "Playlist oluştur",
  "Mutlu şarkılar",
  "Çalışma müziği",
  "Türkçe pop",
  "Sakin müzikler",
  "Enerjik parçalar",
] as const;

export const SIDEBAR_NAVIGATION = [
  {
    id: "home",
    title: "Ana Sayfa",
    icon: "fas fa-home",
    path: "/",
    active: true,
  },
  {
    id: "search",
    title: "Keşfet",
    icon: "fas fa-search",
    path: "/search",
    active: false,
  },
  {
    id: "trending",
    title: "Trendler",
    icon: "fas fa-fire",
    path: "/trending",
    active: false,
  },
] as const;

export const LIBRARY_NAVIGATION = [
  {
    id: "liked",
    title: "Beğendiklerim",
    icon: "fas fa-heart",
    path: "/liked",
  },
  {
    id: "playlists",
    title: "Çalma Listelerim",
    icon: "fas fa-list",
    path: "/playlists",
  },
  {
    id: "recent",
    title: "Son Çalınanlar",
    icon: "fas fa-history",
    path: "/recent",
  },
] as const;
