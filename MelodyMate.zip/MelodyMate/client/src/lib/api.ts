import { Track, Playlist, AiInteraction, UserPreferences } from "@shared/schema";

const API_BASE = "";

export const api = {
  // Tracks
  tracks: {
    getAll: async (): Promise<Track[]> => {
      const response = await fetch(`${API_BASE}/api/tracks`);
      if (!response.ok) throw new Error("Failed to fetch tracks");
      return response.json();
    },
    
    getTrending: async (): Promise<Track[]> => {
      const response = await fetch(`${API_BASE}/api/tracks/trending`);
      if (!response.ok) throw new Error("Failed to fetch trending tracks");
      return response.json();
    },
    
    search: async (query: string): Promise<Track[]> => {
      const response = await fetch(`${API_BASE}/api/tracks/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error("Failed to search tracks");
      return response.json();
    },
    
    create: async (track: Partial<Track>): Promise<Track> => {
      const response = await fetch(`${API_BASE}/api/tracks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(track),
      });
      if (!response.ok) throw new Error("Failed to create track");
      return response.json();
    },
    
    update: async (id: string, updates: Partial<Track>): Promise<Track> => {
      const response = await fetch(`${API_BASE}/api/tracks/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!response.ok) throw new Error("Failed to update track");
      return response.json();
    },
  },

  // Playlists
  playlists: {
    getAll: async (): Promise<Playlist[]> => {
      const response = await fetch(`${API_BASE}/api/playlists`);
      if (!response.ok) throw new Error("Failed to fetch playlists");
      return response.json();
    },
    
    getById: async (id: string): Promise<Playlist> => {
      const response = await fetch(`${API_BASE}/api/playlists/${id}`);
      if (!response.ok) throw new Error("Failed to fetch playlist");
      return response.json();
    },
    
    create: async (playlist: Partial<Playlist>): Promise<Playlist> => {
      const response = await fetch(`${API_BASE}/api/playlists`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(playlist),
      });
      if (!response.ok) throw new Error("Failed to create playlist");
      return response.json();
    },
    
    update: async (id: string, updates: Partial<Playlist>): Promise<Playlist> => {
      const response = await fetch(`${API_BASE}/api/playlists/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!response.ok) throw new Error("Failed to update playlist");
      return response.json();
    },
    
    delete: async (id: string): Promise<void> => {
      const response = await fetch(`${API_BASE}/api/playlists/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete playlist");
    },
  },

  // AI Chat
  ai: {
    getInteractions: async (): Promise<AiInteraction[]> => {
      const response = await fetch(`${API_BASE}/api/ai/interactions`);
      if (!response.ok) throw new Error("Failed to fetch AI interactions");
      return response.json();
    },
    
    chat: async (query: string): Promise<AiInteraction> => {
      const response = await fetch(`${API_BASE}/api/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      if (!response.ok) throw new Error("Failed to send AI chat");
      return response.json();
    },
  },

  // External Search
  external: {
    search: async (query: string, platform?: string): Promise<Track[]> => {
      const url = new URL(`${API_BASE}/api/external/search`);
      url.searchParams.set("q", query);
      if (platform) url.searchParams.set("platform", platform);
      
      const response = await fetch(url.toString());
      if (!response.ok) throw new Error("Failed to search external platforms");
      return response.json();
    },
  },

  // User Preferences
  user: {
    getPreferences: async (): Promise<UserPreferences> => {
      const response = await fetch(`${API_BASE}/api/user/preferences`);
      if (!response.ok) throw new Error("Failed to fetch user preferences");
      return response.json();
    },
    
    updatePreferences: async (updates: Partial<UserPreferences>): Promise<UserPreferences> => {
      const response = await fetch(`${API_BASE}/api/user/preferences`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!response.ok) throw new Error("Failed to update user preferences");
      return response.json();
    },
  },
};
